# ============================================================
# utils/bse_parser.py — BSE Filing Parser v1.0
# ============================================================
# Auto-downloads quarterly investor presentations and results
# from BSE (bseindia.com) and extracts key metrics that are
# unavailable from Yahoo Finance or Screener.in:
#
#   Banks:     CASA ratio, CAR, NIM, GNPA, NNPA, Credit Cost
#   Insurance: VNB margin, EV, Solvency ratio, Claims ratio
#   NBFC:      AUM, Stage-2/3 assets, Credit Cost, CoF
#   Generic:   Order book, capacity utilisation (infra/capital goods)
#
# Architecture:
#   1. BSE search API  → find latest filing URLs for ticker
#   2. requests        → download PDF bytes
#   3. pdfplumber      → extract raw text from PDF
#   4. Regex patterns  → extract structured metrics
#   5. Cache layer     → skip re-download if file exists today
#
# No paid APIs. No auth. Fully public BSE data.
# ============================================================

import os
import re
import time
import json
import hashlib
import requests
from pathlib import Path
from datetime import datetime, timedelta
from loguru import logger


# ── Cache directory ───────────────────────────────────────────
CACHE_DIR  = Path("data/bse_cache")
CACHE_DAYS = 7          # Re-download after 7 days
PDF_DIR    = Path("data/bse_pdfs")

CACHE_DIR.mkdir(parents=True, exist_ok=True)
PDF_DIR.mkdir(parents=True, exist_ok=True)

# ── HTTP headers (mimic browser to avoid bot-blocking) ────────
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "application/json, text/html, */*",
    "Referer": "https://www.bseindia.com/",
}

# ── BSE Security Code map for common Nifty 50 stocks ─────────
# BSE uses numeric codes, Yahoo uses NSE ticker symbols
# We maintain a lookup for the most common stocks
BSE_CODE_MAP = {
    # Banking
    "HDFCBANK":   "500180",
    "ICICIBANK":  "532174",
    "SBIN":       "500112",
    "KOTAKBANK":  "500247",
    "AXISBANK":   "532215",
    "INDUSINDBK": "532187",
    "BANDHANBNK": "541153",
    "IDFCFIRSTB": "539437",
    "FEDERALBNK": "500469",
    "YESBANK":    "532648",
    # NBFC
    "BAJFINANCE": "500034",
    "BAJAJFINSV": "532978",
    "HDFCAMC":    "541729",
    "MUTHOOTFIN": "533398",
    "CHOLAFIN":   "590005",
    # Insurance
    "HDFCLIFE":   "540777",
    "SBILIFE":    "540719",
    "ICICIPRU":   "540133",
    "STARHEALTH": "543412",
    "LICI":       "543526",
    # IT
    "TCS":        "532540",
    "INFY":       "500209",
    "WIPRO":      "507685",
    "HCLTECH":    "532281",
    "TECHM":      "532755",
    "LTIM":       "540005",
    # FMCG
    "HINDUNILVR": "500696",
    "ITC":        "500875",
    "NESTLEIND":  "500790",
    "BRITANNIA":  "500825",
    "MARICO":     "531642",
    "DABUR":      "500096",
    "TATACONSUM": "500800",
    # Auto
    "MARUTI":     "532500",
    "TATAMOTORS": "500570",
    "BAJAJ-AUTO": "532977",
    "EICHERMOT":  "505200",
    "HEROMOTOCO": "500182",
    "M&M":        "500520",
    # Pharma
    "SUNPHARMA":  "524715",
    "DRREDDY":    "500124",
    "CIPLA":      "500087",
    "DIVISLAB":   "532488",
    "APOLLOHOSP": "508869",
    # Industrials
    "LT":         "500510",
    "NTPC":       "532555",
    "POWERGRID":  "532898",
    "ONGC":       "500312",
    "ADANIPORTS": "532921",
    # Materials
    "TATASTEEL":  "500470",
    "JSWSTEEL":   "500228",
    "HINDALCO":   "500440",
    "COALINDIA":  "533278",
    # Telecom / Energy
    "BHARTIARTL": "532454",
    "RELIANCE":   "500325",
}

# ── Filing categories on BSE ──────────────────────────────────
# These are the BSE category codes for different filing types
FILING_CATEGORIES = {
    "results":       "Result",          # Quarterly financial results
    "presentation":  "Investor Presentation",  # Investor day / analyst presentations
    "annual":        "Annual Report",   # Annual reports
}


# ============================================================
# BSE FILING SEARCH
# ============================================================

class BSEFilingParser:
    """
    Downloads and parses BSE quarterly filings to extract
    key banking/insurance/NBFC metrics unavailable elsewhere.

    Usage:
        parser = BSEFilingParser("HDFCBANK")
        data = parser.get_filing_data()
        # Returns: {"casa": 38.5, "car": 18.2, "nim": 3.6, ...}
    """

    def __init__(self, ticker: str):
        self.ticker   = ticker.upper().strip()
        self.bse_code = BSE_CODE_MAP.get(self.ticker)
        self.session  = requests.Session()
        self.session.headers.update(HEADERS)

    # ──────────────────────────────────────────────────────────
    # CACHE HELPERS
    # ──────────────────────────────────────────────────────────

    def _cache_path(self, key: str) -> Path:
        safe = hashlib.md5(key.encode()).hexdigest()[:12]
        return CACHE_DIR / f"{self.ticker}_{safe}.json"

    def _cache_valid(self, path: Path) -> bool:
        if not path.exists():
            return False
        age = datetime.now() - datetime.fromtimestamp(path.stat().st_mtime)
        return age < timedelta(days=CACHE_DAYS)

    def _cache_read(self, path: Path) -> dict:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _cache_write(self, path: Path, data: dict):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    # ──────────────────────────────────────────────────────────
    # BSE API: FIND FILINGS
    # ──────────────────────────────────────────────────────────

    def _get_bse_filings(self, category: str = "Result", max_results: int = 5) -> list:
        """
        Query BSE API to get list of recent filings for this stock.
        Returns list of filing dicts with URL, date, description.
        """
        if not self.bse_code:
            logger.warning(f"⚠️ BSE code not found for {self.ticker} — add to BSE_CODE_MAP")
            return []

        cache_key = f"filings_{category}_{self.bse_code}"
        cache_path = self._cache_path(cache_key)
        if self._cache_valid(cache_path):
            return self._cache_read(cache_path)

        try:
            # BSE filing search API (public endpoint)
            url = (
                f"https://api.bseindia.com/BseIndiaAPI/api/AnnSubCategoryGetData/w"
                f"?strCat={category}&strType=C&strScrip={self.bse_code}"
                f"&strSearch=P&strToDate=&strFromDate=&myClient="
            )
            resp = self.session.get(url, timeout=15)
            resp.raise_for_status()
            data = resp.json()

            filings = []
            for item in data.get("Table", [])[:max_results]:
                # NSURL = BSE stock page (HTML) — never use for PDF download
                # ATTACHMENTNAME = actual PDF filename — always use this
                attach = item.get("ATTACHMENTNAME", "").strip()
                if not attach:
                    continue
                # AttachHis is the correct BSE PDF path (confirmed working)
                filing_url = f"https://www.bseindia.com/xml-data/corpfiling/AttachHis/{attach}"
                filings.append({
                    "url":         filing_url,
                    "date":        item.get("News_submission_dt", ""),
                    "description": item.get("NEWSSUB", ""),
                    "category":    category,
                })

            self._cache_write(cache_path, filings)
            logger.info(f"📂 BSE: Found {len(filings)} '{category}' filings for {self.ticker}")
            return filings

        except Exception as e:
            logger.warning(f"⚠️ BSE filing search failed for {self.ticker}: {e}")
            return []

    # ──────────────────────────────────────────────────────────
    # PDF DOWNLOAD
    # ──────────────────────────────────────────────────────────

    def _download_pdf(self, url: str) -> Path | None:
        """Download a PDF from BSE and save locally. Returns local path."""
        # Use URL hash as filename to avoid re-downloads
        fname = hashlib.md5(url.encode()).hexdigest()[:16] + ".pdf"
        local = PDF_DIR / fname

        # Already downloaded?
        if local.exists() and local.stat().st_size > 1000:
            logger.info(f"📄 PDF cached: {local.name}")
            return local

        try:
            logger.info(f"⬇️  Downloading PDF: {url[:70]}...")
            resp = self.session.get(url, timeout=30, stream=True)
            resp.raise_for_status()

            if "pdf" not in resp.headers.get("Content-Type", "").lower():
                logger.warning(f"⚠️ Not a PDF: {url}")
                return None

            with open(local, "wb") as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    f.write(chunk)

            size_kb = local.stat().st_size // 1024
            logger.info(f"✅ Downloaded {size_kb} KB → {local.name}")
            return local

        except Exception as e:
            logger.warning(f"⚠️ PDF download failed: {e}")
            return None

    # ──────────────────────────────────────────────────────────
    # PDF TEXT EXTRACTION
    # ──────────────────────────────────────────────────────────

    def _extract_text(self, pdf_path: Path) -> str:
        """Extract all text from a PDF file."""
        try:
            import pdfplumber
            text = ""
            with pdfplumber.open(pdf_path) as pdf:
                for page in pdf.pages[:40]:  # First 40 pages (enough for results)
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
            logger.info(f"📝 Extracted {len(text):,} chars from PDF")
            return text
        except ImportError:
            logger.warning("⚠️ pdfplumber not installed — run: pip install pdfplumber")
            return ""
        except Exception as e:
            logger.warning(f"⚠️ PDF text extraction failed: {e}")
            return ""

    # ──────────────────────────────────────────────────────────
    # REGEX EXTRACTION — BANKING
    # ──────────────────────────────────────────────────────────

    def _extract_banking_metrics(self, text: str) -> dict:
        """
        Extract key banking metrics from PDF text using regex patterns.
        Handles variations in formatting across different bank reports.
        """
        result = {}

        def find_pct(patterns: list, text: str) -> float | None:
            """Try multiple regex patterns, return first match as float."""
            for pattern in patterns:
                match = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
                if match:
                    try:
                        val = float(match.group(1).replace(",", ""))
                        if 0 < val < 100:  # Sanity check — must be a percentage
                            return round(val, 2)
                    except:
                        pass
            return None

        def find_num(patterns: list, text: str) -> float | None:
            """Try multiple regex patterns, return first match as float."""
            for pattern in patterns:
                match = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
                if match:
                    try:
                        return float(match.group(1).replace(",", ""))
                    except:
                        pass
            return None

        # ── CASA Ratio ────────────────────────────────────────
        casa = find_pct([
            r"CASA\s+Ratio\s*[:\-]?\s*([\d.]+)\s*%",
            r"CASA\s*[:\-]\s*([\d.]+)\s*%",
            r"Current\s+&\s+Savings\s+[:\-]?\s*([\d.]+)\s*%",
            r"CASA\s+deposits?\s+.*?([\d.]+)\s*%",
            r"(?:^|\s)CASA\s+([\d.]+)%",
        ], text)
        if casa:
            result["casa"] = casa
            logger.info(f"  ✅ CASA: {casa}%")

        # ── CAR / Capital Adequacy Ratio ──────────────────────
        car = find_pct([
            r"Capital\s+Adequacy\s+Ratio\s*[:\-]?\s*([\d.]+)\s*%",
            r"CRAR\s*[:\-]?\s*([\d.]+)\s*%",
            r"CAR\s*[:\-]?\s*([\d.]+)\s*%",
            r"Total\s+Capital\s+Ratio\s*[:\-]?\s*([\d.]+)\s*%",
            r"(?:Tier\s*I\s*&\s*II|Total\s+CAR)\s*[:\-]?\s*([\d.]+)",
        ], text)
        if car:
            result["car"] = car
            logger.info(f"  ✅ CAR: {car}%")

        # ── NIM / Net Interest Margin ─────────────────────────
        nim = find_pct([
            r"Net\s+Interest\s+Margin\s*[:\-]?\s*([\d.]+)\s*%",
            r"NIM\s*[:\-]?\s*([\d.]+)\s*%",
            r"NIM\s+\(annualised\)\s*[:\-]?\s*([\d.]+)\s*%",
            r"Net\s+Interest\s+Margin\s*\(.*?\)\s*[:\-]?\s*([\d.]+)",
        ], text)
        if nim:
            result["nim"] = nim
            logger.info(f"  ✅ NIM: {nim}%")

        # ── GNPA / Gross NPA ──────────────────────────────────
        gnpa = find_pct([
            r"Gross\s+NPA\s*[:\-]?\s*([\d.]+)\s*%",
            r"GNPA\s*[:\-]?\s*([\d.]+)\s*%",
            r"Gross\s+NPL\s*[:\-]?\s*([\d.]+)\s*%",
            r"Gross\s+Non[- ]Performing\s+Assets?\s*[:\-]?\s*([\d.]+)\s*%",
        ], text)
        if gnpa:
            result["gnpa"] = gnpa
            logger.info(f"  ✅ GNPA: {gnpa}%")

        # ── NNPA / Net NPA ────────────────────────────────────
        nnpa = find_pct([
            r"Net\s+NPA\s*[:\-]?\s*([\d.]+)\s*%",
            r"NNPA\s*[:\-]?\s*([\d.]+)\s*%",
            r"Net\s+Non[- ]Performing\s+Assets?\s*[:\-]?\s*([\d.]+)\s*%",
        ], text)
        if nnpa:
            result["nnpa"] = nnpa
            logger.info(f"  ✅ NNPA: {nnpa}%")

        # ── Credit Cost ───────────────────────────────────────
        credit_cost = find_pct([
            r"Credit\s+Cost\s*[:\-]?\s*([\d.]+)\s*%",
            r"Credit\s+costs?\s*\(annualised\)\s*[:\-]?\s*([\d.]+)",
            r"Provision\s+Coverage\s+Ratio\s*[:\-]?\s*([\d.]+)\s*%",
        ], text)
        if credit_cost:
            result["credit_cost"] = credit_cost
            logger.info(f"  ✅ Credit Cost: {credit_cost}%")

        # ── ROA ───────────────────────────────────────────────
        roa = find_pct([
            r"Return\s+on\s+Assets?\s*[:\-]?\s*([\d.]+)\s*%",
            r"ROA\s*[:\-]?\s*([\d.]+)\s*%",
            r"RoA\s*\(annualised\)\s*[:\-]?\s*([\d.]+)",
        ], text)
        if roa:
            result["roa_pdf"] = roa
            logger.info(f"  ✅ ROA (PDF): {roa}%")

        # ── ROE ───────────────────────────────────────────────
        roe = find_pct([
            r"Return\s+on\s+Equity\s*[:\-]?\s*([\d.]+)\s*%",
            r"ROE\s*[:\-]?\s*([\d.]+)\s*%",
            r"RoE\s*\(annualised\)\s*[:\-]?\s*([\d.]+)",
        ], text)
        if roe:
            result["roe_pdf"] = roe
            logger.info(f"  ✅ ROE (PDF): {roe}%")

        # ── Cost of Funds ─────────────────────────────────────
        cof = find_pct([
            r"Cost\s+of\s+Funds?\s*[:\-]?\s*([\d.]+)\s*%",
            r"Cost\s+of\s+Borrowings?\s*[:\-]?\s*([\d.]+)\s*%",
            r"Cost\s+of\s+Liabilities\s*[:\-]?\s*([\d.]+)\s*%",
        ], text)
        if cof:
            result["cost_of_funds"] = cof
            logger.info(f"  ✅ Cost of Funds: {cof}%")

        return result

    # ──────────────────────────────────────────────────────────
    # REGEX EXTRACTION — INSURANCE
    # ──────────────────────────────────────────────────────────

    def _extract_insurance_metrics(self, text: str) -> dict:
        result = {}

        def find_pct(patterns, text):
            for pattern in patterns:
                match = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
                if match:
                    try:
                        val = float(match.group(1).replace(",", ""))
                        if 0 < val < 200:
                            return round(val, 2)
                    except:
                        pass
            return None

        def find_num(patterns, text, scale=1):
            for pattern in patterns:
                match = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
                if match:
                    try:
                        return round(float(match.group(1).replace(",", "")) * scale, 2)
                    except:
                        pass
            return None

        # ── VNB Margin ────────────────────────────────────────
        vnb_margin = find_pct([
            r"VNB\s+Margin\s*[:\-]?\s*([\d.]+)\s*%",
            r"Value\s+of\s+New\s+Business\s+Margin\s*[:\-]?\s*([\d.]+)\s*%",
            r"NBM\s*[:\-]?\s*([\d.]+)\s*%",
            r"New\s+Business\s+Margin\s*[:\-]?\s*([\d.]+)\s*%",
        ], text)
        if vnb_margin:
            result["vnb_margin"] = vnb_margin
            logger.info(f"  ✅ VNB Margin: {vnb_margin}%")

        # ── Solvency Ratio ────────────────────────────────────
        solvency = find_pct([
            r"Solvency\s+Ratio\s*[:\-]?\s*([\d.]+)\s*%",
            r"Solvency\s+Margin\s*[:\-]?\s*([\d.]+)\s*%",
            r"Solvency\s*[:\-]?\s*([\d.]+)x",
        ], text)
        if solvency:
            result["solvency_ratio"] = solvency
            logger.info(f"  ✅ Solvency: {solvency}%")

        # ── Claims Ratio ──────────────────────────────────────
        claims = find_pct([
            r"Claims\s+Ratio\s*[:\-]?\s*([\d.]+)\s*%",
            r"Loss\s+Ratio\s*[:\-]?\s*([\d.]+)\s*%",
            r"Incurred\s+Claims?\s+Ratio\s*[:\-]?\s*([\d.]+)\s*%",
            r"(?:Net\s+)?Claims?\s+paid\s+ratio\s*[:\-]?\s*([\d.]+)",
        ], text)
        if claims:
            result["claims_ratio"] = claims
            logger.info(f"  ✅ Claims Ratio: {claims}%")

        # ── Combined Ratio ────────────────────────────────────
        combined = find_pct([
            r"Combined\s+Ratio\s*[:\-]?\s*([\d.]+)\s*%",
            r"Expense\s+of\s+Management\s+Ratio\s*[:\-]?\s*([\d.]+)\s*%",
        ], text)
        if combined:
            result["combined_ratio"] = combined
            logger.info(f"  ✅ Combined Ratio: {combined}%")

        # ── Embedded Value ────────────────────────────────────
        ev = find_num([
            r"Embedded\s+Value\s*[:\-]?\s*(?:Rs\.?|₹|INR)?\s*([\d,]+(?:\.\d+)?)\s*(?:Cr|crore|Bn|billion)?",
            r"EV\s+(?:per\s+share)?\s*[:\-]?\s*(?:Rs\.?|₹)?\s*([\d,]+)",
        ], text)
        if ev and ev > 100:  # Must be > ₹100 to be plausible
            result["embedded_value_cr"] = ev
            logger.info(f"  ✅ Embedded Value: ₹{ev} Cr")

        # ── VNB ───────────────────────────────────────────────
        vnb = find_num([
            r"Value\s+of\s+New\s+Business\s*[:\-]?\s*(?:Rs\.?|₹|INR)?\s*([\d,]+(?:\.\d+)?)\s*(?:Cr|crore)?",
            r"VNB\s*[:\-]?\s*(?:Rs\.?|₹)?\s*([\d,]+(?:\.\d+)?)\s*(?:Cr|crore)?",
        ], text)
        if vnb and vnb > 10:
            result["vnb_cr"] = vnb
            logger.info(f"  ✅ VNB: ₹{vnb} Cr")

        # ── 13th Month Persistency ────────────────────────────
        persistency = find_pct([
            r"13th\s+Month\s+Persistency\s*[:\-]?\s*([\d.]+)\s*%",
            r"Persistency\s+\(13th\s+Month\)\s*[:\-]?\s*([\d.]+)\s*%",
        ], text)
        if persistency:
            result["persistency_13m"] = persistency
            logger.info(f"  ✅ 13M Persistency: {persistency}%")

        return result

    # ──────────────────────────────────────────────────────────
    # REGEX EXTRACTION — NBFC
    # ──────────────────────────────────────────────────────────

    def _extract_nbfc_metrics(self, text: str) -> dict:
        result = {}

        def find_pct(patterns, text):
            for pattern in patterns:
                match = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
                if match:
                    try:
                        val = float(match.group(1).replace(",", ""))
                        if 0 < val < 100:
                            return round(val, 2)
                    except:
                        pass
            return None

        def find_num(patterns, text):
            for pattern in patterns:
                match = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
                if match:
                    try:
                        return float(match.group(1).replace(",", ""))
                    except:
                        pass
            return None

        # ── AUM ───────────────────────────────────────────────
        aum = find_num([
            r"AUM\s*[:\-]?\s*(?:Rs\.?|₹|INR)?\s*([\d,]+(?:\.\d+)?)\s*(?:Cr|crore)",
            r"Assets\s+Under\s+Management\s*[:\-]?\s*(?:Rs\.?|₹)?\s*([\d,]+)",
            r"Loan\s+Book\s*[:\-]?\s*(?:Rs\.?|₹)?\s*([\d,]+(?:\.\d+)?)\s*(?:Cr|crore)",
        ], text)
        if aum and aum > 1000:
            result["aum_cr"] = aum
            logger.info(f"  ✅ AUM: ₹{aum:,.0f} Cr")

        # ── Yield on Assets ───────────────────────────────────
        yield_on_assets = find_pct([
            r"Yield\s+on\s+Assets?\s*[:\-]?\s*([\d.]+)\s*%",
            r"Yield\s+on\s+Loan\s+Book\s*[:\-]?\s*([\d.]+)\s*%",
            r"Interest\s+Yield\s*[:\-]?\s*([\d.]+)\s*%",
        ], text)
        if yield_on_assets:
            result["yield_on_assets"] = yield_on_assets
            logger.info(f"  ✅ Yield on Assets: {yield_on_assets}%")

        # ── Stage-2 Assets ────────────────────────────────────
        stage2 = find_pct([
            r"Stage\s*[-\s]?2\s*[:\-]?\s*([\d.]+)\s*%",
            r"Stage\s+II\s*[:\-]?\s*([\d.]+)\s*%",
        ], text)
        if stage2:
            result["stage2_pct"] = stage2
            logger.info(f"  ✅ Stage-2: {stage2}%")

        # ── Stage-3 / NPA ─────────────────────────────────────
        stage3 = find_pct([
            r"Stage\s*[-\s]?3\s*[:\-]?\s*([\d.]+)\s*%",
            r"Stage\s+III\s*[:\-]?\s*([\d.]+)\s*%",
        ], text)
        if stage3:
            result["stage3_pct"] = stage3
            logger.info(f"  ✅ Stage-3: {stage3}%")

        # ── Credit Cost ───────────────────────────────────────
        credit_cost = find_pct([
            r"Credit\s+Cost\s*[:\-]?\s*([\d.]+)\s*%",
            r"Loan\s+Loss\s+Provision\s*[:\-]?\s*([\d.]+)\s*%",
        ], text)
        if credit_cost:
            result["credit_cost"] = credit_cost
            logger.info(f"  ✅ Credit Cost: {credit_cost}%")

        return result

    # ──────────────────────────────────────────────────────────
    # MAIN: GET FILING DATA
    # ──────────────────────────────────────────────────────────

    def get_filing_data(self, sector_type: str = "BANKING") -> dict:
        """
        Main entry point. Downloads and parses the latest quarterly
        filing for this stock and returns extracted metrics.

        Args:
            sector_type: "BANKING", "NBFC", "INSURANCE", or "GENERIC"

        Returns:
            dict of extracted metrics, e.g.:
            {
                "casa": 42.3, "car": 18.1, "nim": 3.6,
                "gnpa": 1.3, "nnpa": 0.4,
                "source": "BSE Q3FY25 results",
                "date": "2025-01-15",
            }
        """
        if not self.bse_code:
            logger.warning(f"⚠️ {self.ticker}: BSE code unknown — add to BSE_CODE_MAP in bse_parser.py")
            return {"source": "BSE code not mapped"}

        # Check JSON cache first (avoid re-parsing same PDF)
        cache_key = f"parsed_{sector_type}_{self.bse_code}"
        cache_path = self._cache_path(cache_key)
        if self._cache_valid(cache_path):
            data = self._cache_read(cache_path)
            logger.info(f"📦 BSE data from cache ({len(data)} fields) for {self.ticker}")
            return data

        logger.info(f"🏛️  BSE Parser: Searching filings for {self.ticker} ({self.bse_code})...")

        # Try investor presentation first (more detailed), then quarterly results
        all_metrics = {}
        sources_tried = []

        for category in ["Investor Presentation", "Result"]:
            filings = self._get_bse_filings(category=category, max_results=3)
            if not filings:
                continue

            for filing in filings[:2]:  # Try top 2 filings
                url  = filing["url"]
                date = filing["date"][:10] if filing["date"] else "unknown"

                # Only process PDFs
                if not url.lower().endswith(".pdf") and "pdf" not in url.lower():
                    continue

                pdf_path = self._download_pdf(url)
                if not pdf_path:
                    continue

                text = self._extract_text(pdf_path)
                if len(text) < 500:
                    logger.warning(f"⚠️ PDF text too short ({len(text)} chars) — skipping")
                    continue

                logger.info(f"🔍 Parsing {sector_type} metrics from {filing['description'][:50]}...")

                # Extract based on sector
                if sector_type in ("BANKING",):
                    metrics = self._extract_banking_metrics(text)
                elif sector_type == "NBFC":
                    metrics = {**self._extract_nbfc_metrics(text),
                               **self._extract_banking_metrics(text)}
                elif sector_type == "INSURANCE":
                    metrics = self._extract_insurance_metrics(text)
                else:
                    metrics = {}

                if metrics:
                    metrics["source"] = f"BSE {filing['description'][:40]}"
                    metrics["date"]   = date
                    all_metrics.update(metrics)
                    sources_tried.append(filing["description"][:40])
                    logger.info(f"  ✅ Extracted {len(metrics)-2} metrics from {category}")

                    # If we got the key metrics, stop searching
                    if sector_type in ("BANKING",) and all(
                        k in all_metrics for k in ["casa", "car", "nim"]
                    ):
                        break
                    elif sector_type == "INSURANCE" and all(
                        k in all_metrics for k in ["vnb_margin", "solvency_ratio"]
                    ):
                        break

                time.sleep(2)  # Be polite to BSE servers

            if all_metrics:
                break  # Found enough from first category

        if not all_metrics:
            logger.warning(f"⚠️ {self.ticker}: No metrics extracted from BSE filings")
            all_metrics = {"source": "BSE: no data extracted", "date": ""}
        else:
            n = len([k for k in all_metrics if k not in ("source", "date")])
            logger.info(f"✅ BSE Parser: {n} metrics extracted for {self.ticker}")

        # Cache the result
        self._cache_write(cache_path, all_metrics)
        return all_metrics


# ============================================================
# CONVENIENCE FUNCTION
# ============================================================

def get_bse_data(ticker: str, sector_type: str = "BANKING") -> dict:
    """
    One-line helper to get BSE filing data for any stock.

    Usage:
        from utils.bse_parser import get_bse_data
        data = get_bse_data("HDFCBANK", "BANKING")
        casa = data.get("casa")   # e.g. 42.3
        car  = data.get("car")    # e.g. 18.1
    """
    parser = BSEFilingParser(ticker)
    return parser.get_filing_data(sector_type=sector_type)


# ============================================================
# STANDALONE TEST
# ============================================================

if __name__ == "__main__":
    import sys
    from rich.console import Console
    from rich.table import Table
    from rich import box

    console = Console()

    tickers = sys.argv[1:] if len(sys.argv) > 1 else ["HDFCBANK", "BAJFINANCE", "HDFCLIFE"]

    for ticker in tickers:
        console.print(f"\n[bold cyan]━━━ Testing BSE Parser: {ticker} ━━━[/bold cyan]")

        # Auto-detect sector for test
        sector_map = {
            "HDFCBANK": "BANKING", "ICICIBANK": "BANKING", "SBIN": "BANKING",
            "KOTAKBANK": "BANKING", "AXISBANK": "BANKING",
            "BAJFINANCE": "NBFC", "BAJAJFINSV": "NBFC",
            "HDFCLIFE": "INSURANCE", "SBILIFE": "INSURANCE", "ICICIPRU": "INSURANCE",
        }
        sector = sector_map.get(ticker, "BANKING")

        data = get_bse_data(ticker, sector)

        t = Table(title=f"BSE Data — {ticker}", box=box.ROUNDED,
                  header_style="bold white")
        t.add_column("Metric", width=24)
        t.add_column("Value",  width=14)
        t.add_column("Status", width=10)

        key_metrics = {
            "BANKING":   ["casa", "car", "nim", "gnpa", "nnpa", "credit_cost", "roa_pdf", "roe_pdf", "cost_of_funds"],
            "NBFC":      ["aum_cr", "yield_on_assets", "stage2_pct", "stage3_pct", "credit_cost", "gnpa", "nnpa"],
            "INSURANCE": ["vnb_margin", "solvency_ratio", "claims_ratio", "combined_ratio", "embedded_value_cr", "vnb_cr", "persistency_13m"],
        }

        for metric in key_metrics.get(sector, []):
            val = data.get(metric)
            status = "✅" if val else "❌"
            val_str = f"{val}%" if val and "cr" not in metric else (f"₹{val:,.0f} Cr" if val else "—")
            t.add_row(metric, val_str, status)

        t.add_row("source", data.get("source", "—")[:40], "ℹ️")
        t.add_row("date",   data.get("date", "—"), "ℹ️")
        console.print(t)
